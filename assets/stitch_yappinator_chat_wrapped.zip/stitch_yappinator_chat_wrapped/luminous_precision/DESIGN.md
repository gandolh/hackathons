---
name: Luminous Precision
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#424754'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#727785'
  outline-variant: '#c2c6d6'
  surface-tint: '#005ac2'
  primary: '#0058be'
  on-primary: '#ffffff'
  primary-container: '#2170e4'
  on-primary-container: '#fefcff'
  inverse-primary: '#adc6ff'
  secondary: '#8127cf'
  on-secondary: '#ffffff'
  secondary-container: '#9c48ea'
  on-secondary-container: '#fffbff'
  tertiary: '#924700'
  on-tertiary: '#ffffff'
  tertiary-container: '#b75b00'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#f0dbff'
  secondary-fixed-dim: '#ddb7ff'
  on-secondary-fixed: '#2c0051'
  on-secondary-fixed-variant: '#6900b3'
  tertiary-fixed: '#ffdcc6'
  tertiary-fixed-dim: '#ffb786'
  on-tertiary-fixed: '#311400'
  on-tertiary-fixed-variant: '#723600'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Archivo Narrow
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Archivo Narrow
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Archivo Narrow
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.02em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: '0'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: '0'
  label-sm:
    fontFamily: Geist
    fontSize: 13px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 48px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
---

## Brand & Style

The design system is engineered for high-velocity communication, balancing a structured, utilitarian core with expressive, energetic accents. The aesthetic leans into **Modern Minimalism** with a **Brutalist** edge—prioritizing clarity, information density, and sharp geometric precision. 

The target audience consists of power users who value speed and legibility. By utilizing a pure white canvas and a high-contrast typographic hierarchy, the UI evokes a sense of organized efficiency. The emotional response is one of clarity and focus, where the "You" and "Them" interactions are instantly distinguishable through vibrant, saturated color logic against a clinical, professional backdrop.

## Colors

The palette is anchored by a pure white background to maximize "breathability" and perceived speed. 

- **Primary ('You'):** A high-energy blue (#3b82f6) used for user-originated actions and messages.
- **Secondary ('Them'):** A vibrant purple (#a855f7) used to differentiate incoming data or external participants.
- **Neutral:** A deep navy (#0f172a) ensures peak legibility for all body copy and interface labels.
- **Surface:** A cool-toned light gray (#f8fafc) is used to create subtle containment for cards and secondary interface panels, maintaining a clean separation from the main background without heavy shadows.

## Typography

This design system employs a tiered typographic strategy to balance impact with utility. 

**Archivo Narrow** is used for display and headlines to provide a condensed, urgent, and authoritative feel. **Inter** serves as the workhorse for body content, chosen for its exceptional readability in high-density messaging environments. **Geist** is utilized for technical labels and metadata, providing a precise, developer-friendly aesthetic that reinforces the system's focus on data. Use all-caps sparingly for labels to enhance scannability.

## Layout & Spacing

The layout follows a **Fluid Grid** model based on a 4px baseline rhythm. 

- **Desktop:** 12-column grid with 16px gutters and 32px outer margins.
- **Tablet:** 8-column grid with 16px gutters.
- **Mobile:** 4-column grid with 16px gutters and 16px outer margins.

Spacing should be used to create clear groupings of information. Elements like message bubbles and input fields should use the `md` (16px) unit for internal padding to maintain a comfortable but dense information flow.

## Elevation & Depth

This design system eschews traditional shadows in favor of **Low-Contrast Outlines** and **Tonal Layers**. 

Hierarchy is established by nesting surfaces: the primary background is white, while secondary containers (cards, sidebars) use the Surface color (#f8fafc). To define boundaries, a consistent 1px border (#e2e8f0) is applied to all interactive and contained elements. When an element requires "lift" (e.g., a modal or dropdown), a 2px offset solid border in the Primary or Neutral color is used instead of a shadow, adhering to the system's brutalist-inspired precision.

## Shapes

The shape language is strictly **Sharp**. All UI elements—including buttons, input fields, cards, and message bubbles—utilize 0px corner radii. This reinforces the architectural and precise nature of the brand, ensuring that every element feels deliberate and structural. Circular shapes are reserved exclusively for user avatars to provide a singular point of organic contrast against the rigid grid.

## Components

### Buttons
Primary buttons use a solid #3b82f6 fill with white text. Secondary buttons use a transparent background with a 1px #e2e8f0 border. All buttons are rectangular with sharp corners and use `label-sm` typography.

### Input Fields
Inputs feature a #ffffff background with a 1px #e2e8f0 border. Upon focus, the border shifts to 2px solid #3b82f6. Placeholder text is rendered in a muted navy.

### Cards & Surfaces
Cards use the #f8fafc surface color with a 1px #e2e8f0 border. There is no shadow. For "You" specific context, a 4px left-hand border in #3b82f6 can be added to indicate ownership.

### Message Bubbles
- **You:** Solid #3b82f6 background, white text, sharp corners, right-aligned.
- **Them:** Solid #a855f7 background, white text, sharp corners, left-aligned.
Both bubbles use `body-md` typography with 12px horizontal and 8px vertical padding.

### Lists
List items are separated by 1px #e2e8f0 horizontal dividers. Hover states are indicated by a shift to the #f8fafc surface color.