---
name: Yappinator One Thousand
colors:
  surface: '#10131a'
  surface-dim: '#10131a'
  surface-bright: '#363941'
  surface-container-lowest: '#0b0e15'
  surface-container-low: '#191b23'
  surface-container: '#1d2027'
  surface-container-high: '#272a31'
  surface-container-highest: '#32353c'
  on-surface: '#e1e2ec'
  on-surface-variant: '#c2c6d6'
  inverse-surface: '#e1e2ec'
  inverse-on-surface: '#2e3038'
  outline: '#8c909f'
  outline-variant: '#424754'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e6a'
  primary-container: '#4d8eff'
  on-primary-container: '#00285d'
  inverse-primary: '#005ac2'
  secondary: '#ddb7ff'
  on-secondary: '#490080'
  secondary-container: '#6f00be'
  on-secondary-container: '#d6a9ff'
  tertiary: '#ffb786'
  on-tertiary: '#502400'
  tertiary-container: '#df7412'
  on-tertiary-container: '#461f00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#f0dbff'
  secondary-fixed-dim: '#ddb7ff'
  on-secondary-fixed: '#2c0051'
  on-secondary-fixed-variant: '#6900b3'
  tertiary-fixed: '#ffdcc6'
  tertiary-fixed-dim: '#ffb786'
  on-tertiary-fixed: '#311400'
  on-tertiary-fixed-variant: '#723600'
  background: '#10131a'
  on-background: '#e1e2ec'
  surface-variant: '#32353c'
typography:
  display-wordmark:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '900'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.2'
  data-huge:
    fontFamily: JetBrains Mono
    fontSize: 40px
    fontWeight: '700'
    lineHeight: '1'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 16px
  margin-mobile: 20px
  margin-desktop: 40px
  max-width: 1200px
---

## Brand & Style
The design system for this product is rooted in a "Digital Forensics" aesthetic—blending high-density data analytics with the playful, viral nature of "Wrapped" social sharing. The brand personality is clinical yet witty, treating chat history as a specimen to be dissected. 

The visual style is **High-Contrast Dark Mode**, utilizing a "Terminal-Luxe" approach. It eschews traditional depth markers like shadows in favor of strict structural lines, sharp geometry, and vibrant accent colors that pop against a near-black foundation. The emotional response should be one of intrigued discovery—professional enough to trust the data, but bold enough to feel like an "event."

## Colors
The palette is built for maximum legibility on OLED screens. The background is a deep, near-black neutral to let the vibrant accents define the hierarchy.

- **Primary (Blue):** Represents the "You" entity in all data visualizations and comparison metrics.
- **Secondary (Purple):** Represents the "Other" or "Group" entity, providing a clear spectral distinction from the user.
- **Surface & Border:** Layers are defined solely by value shifts and 1px borders. Use the semi-transparent white border to maintain a "blueprint" feel.
- **Destructive:** A high-chroma red used specifically for "Red Flags" or negative yapping trends.

## Typography
The typography system uses a functional hierarchy to separate narrative from raw data.

- **Headlines:** Utilize **Geist** for its tight apertures and technical feel. The "Yappinator" wordmark should always be rendered in the heaviest weight.
- **Data Values:** All numerical metrics, percentages, and word counts must use **JetBrains Mono**. The monospaced nature ensures that numbers don't "jump" during counting animations and maintains the analytical look.
- **Body & UI:** **Inter** provides a neutral, highly readable base for tooltips, descriptions, and labels.

## Layout & Spacing
This design system employs a **Fluid Grid** model based on a 4px base unit. 

- **Grid:** A 12-column system for desktop, collapsing to a single column for mobile "Stories." 
- **Rhythm:** Use 16px (4 units) for standard gaps between cards and 8px (2 units) for internal card padding between elements.
- **Margins:** Content should have generous horizontal padding on mobile (20px) to ensure data visualizations aren't clipped by device edges.

## Elevation & Depth
In alignment with the high-contrast aesthetic, **no shadows are permitted** in this design system. Depth is created through:
1. **Z-axis Tiers:** The background is the lowest tier, followed by Surface Cards, then Tooltips/Modals.
2. **Stroke Definition:** All interactive or distinct elements are enclosed in a sharp 1px border. 
3. **Contrast:** Higher elevation elements do not get lighter; instead, they maintain a consistent surface color but may use a brighter border or a subtle fill shift to indicate focus.

## Shapes
The shape language is "Soft-Industrial." While the overall feel is sharp and technical, a minimal 4px (`0.25rem`) corner radius is applied to all buttons, cards, and input fields to prevent the UI from feeling hostile. Larger containers (like the main stats card) can scale up to 8px (`0.5rem`) for a more "contained" feel, but interactive components must remain tight at 4px.

## Components
- **Comparison Cards:** Split vertically with a 1px border. The left side (Primary) and right side (Secondary) use their respective accent colors for typography and bars.
- **Buttons:** Sharp 1px borders, 4px radius. Primary buttons use a solid blue fill with black text; secondary buttons are ghost-style with white borders.
- **Word-Count Bars:** Simple horizontal rectangles. The background is a 10% opacity version of the accent color, while the progress fill is 100% opacity. No rounded end-caps; keep them rectangular.
- **Line Charts:** Use a 2px stroke width. Points are marked by small 4px squares rather than circles to maintain the technical geometric theme.
- **Chips:** Small, uppercase labels with a subtle background tint and 1px border, used for categorizing "Yapping Styles" (e.g., "THE NOVELIST", "THE GHOST").
- **Inputs:** Darker than the surface color, with a 1px border that glows Primary Blue when focused.